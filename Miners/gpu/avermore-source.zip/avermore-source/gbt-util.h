#ifndef __GBT_UTIL_H
#define __GBT_UTIL_H


int add_var_int(uint8_t*, uint64_t);
bool set_coinbasetxn(struct pool *, uint32_t, uint64_t, uint64_t, const char *);

#endif
