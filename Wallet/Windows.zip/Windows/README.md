# Raven Wallet Windows Instructions

 1) double click raven-qt.exe to start the wallet

 2) on first start the wallet will have to sync the
    the blockchain this may take anywhere from a few
	  minutes to days depending on your location and
	  internet connection speed.

 3) you can hide the syncing windows but no
    transactions can be made and balances may be
    reported differently till the blockchain has
	  been fully synced
