Releases have been moved to:

https://github.com/RavenProject/Ravencoin/releases/latest
