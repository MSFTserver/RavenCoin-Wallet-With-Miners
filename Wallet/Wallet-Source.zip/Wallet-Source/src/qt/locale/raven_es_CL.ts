<TS language="es_CL" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Haga clic para editar la dirección o etiqueta</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Crea una nueva dirección</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>y nueva</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copia la dirección seleccionada al portapapeles</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>y copiar</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>C y perder</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Eliminar la dirección seleccionada de la lista</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exportar los datos de la pestaña actual a un archivo</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>y exportar</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Borrar</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation>Introduce contraseña actual      </translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nueva contraseña</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Repite nueva contraseña</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>RavenGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Firmar &amp;Mensaje...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Sincronizando con la red...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Vista general</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Muestra una vista general de la billetera</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transacciones</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Explora el historial de transacciónes</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Salir</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Salir del programa</translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation>S&amp;obre %1</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Mostrar Información sobre Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Opciones</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Codificar la billetera...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Respaldar billetera...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Cambiar la contraseña...</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>Mandando direcciones</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>Recibiendo direcciones</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Abrir y url...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Cargando el index de bloques...</translation>
    </message>
    <message>
        <source>Send coins to a Raven address</source>
        <translation>Enviar monedas a una dirección raven</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Respaldar billetera en otra ubicación</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Cambiar la contraseña utilizada para la codificación de la billetera</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>Ventana &amp;Debug</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Abre consola de depuración y diagnóstico</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>Verificar mensaje....</translation>
    </message>
    <message>
        <source>Raven</source>
        <translation>Raven</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Cartera</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Envía</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>y recibir</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Mostrar/Ocultar</translation>
    </message>
    <message>
        <source>Sign messages with your Raven addresses to prove you own them</source>
        <translation>Firmar un mensaje para provar que usted es dueño de esta dirección</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Configuración</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ayuda</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Barra de pestañas</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and raven: URIs)</source>
        <translation>Pide pagos (genera codigos QR and raven: URls)</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Atención</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Actualizado</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Recuperando...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Transacción enviada</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Transacción entrante</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>La billetera esta &lt;b&gt;codificada&lt;/b&gt; y actualmente &lt;b&gt;desbloqueda&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>La billetera esta &lt;b&gt;codificada&lt;/b&gt; y actualmente &lt;b&gt;bloqueda&lt;/b&gt;</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Amount:</source>
        <translation>Cantidad:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>comisión:
</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Confirmaciones</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confirmado</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Editar dirección</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Etiqueta</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Dirección</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>name</source>
        <translation>Nombre</translation>
    </message>
    </context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>versión</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>opciones de linea de comando</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Uso:</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>bienvenido</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>URI:</source>
        <translation>url:</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Principal</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Reestablece todas las opciones.</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Red</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>Cartera</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>experto</translation>
    </message>
    <message>
        <source>Automatically open the Raven client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Abre automáticamente el puerto del cliente Raven en el router. Esto funciona solo cuando tu router es compatible con UPnP y está habilitado.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Direcciona el puerto usando &amp;UPnP</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>&amp;IP Proxy:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Puerto:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Puerto del servidor proxy (ej. 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>y windows
</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Muestra solo un ícono en la bandeja después de minimizar la ventana</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimiza a la bandeja en vez de la barra de tareas</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inimiza a la bandeja al cerrar</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Mostrado</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Unidad en la que mostrar cantitades:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Elige la subdivisión por defecto para mostrar cantidaded en la interfaz cuando se envien monedas</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancela</translation>
    </message>
    <message>
        <source>default</source>
        <translation>predeterminado</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Confirmar reestablecimiento de las opciones</translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 y %2</translation>
    </message>
    </context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Versión del Cliente</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Información</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Ventana Debug</translation>
    </message>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Tiempo de inicio</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Red</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Número de conexiones</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Bloquea cadena</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>version
</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Consola</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Total:</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Limpiar Consola</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>Cantidad:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etiqueta:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;mensaje</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>Código QR </translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>&amp;Copia dirección</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>Guardar imagen...</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Enviar monedas</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Fondos insuficientes</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Cantidad:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>comisión:
</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Comisión transacción:</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normal</translation>
    </message>
    <message>
        <source>fast</source>
        <translation>rapido</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Enviar a múltiples destinatarios</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>&amp;Agrega destinatario</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Borra todos</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Balance:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Confirma el envio</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;Envía</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>Cantidad:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>&amp;Pagar a:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etiqueta:</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Pega dirección desde portapapeles</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Mensaje:</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Pagar a:</translation>
    </message>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Firmar Mensaje</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Pega dirección desde portapapeles</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Escriba el mensaje que desea firmar</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Firma</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Raven address</source>
        <translation>Firmar un mensjage para probar que usted es dueño de esta dirección</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Firmar Mensaje</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Borra todos</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;Firmar Mensaje</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>&amp;Firmar Mensaje</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[red-de-pruebas]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Esta ventana muestra información detallada sobre la transacción</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>raven-core</name>
    <message>
        <source>Options:</source>
        <translation>Opciones:
</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Especifica directorio para los datos
</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Aceptar comandos consola y JSON-RPC
</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Correr como demonio y acepta comandos
</translation>
    </message>
    <message>
        <source>Raven Core</source>
        <translation>raven core</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Error cargando blkindex.dat</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Atención: Poco espacio en el disco duro</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Información</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Enviar informacion de seguimiento a la consola en vez del archivo debug.log</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Usuario para las conexiones JSON-RPC
</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Atención</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Contraseña para las conexiones JSON-RPC
</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Permite búsqueda DNS para addnode y connect
</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Cargando direcciónes...</translation>
    </message>
    <message>
        <source>Invalid -proxy address: '%s'</source>
        <translation>Dirección -proxy invalida: '%s'</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Fondos insuficientes</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Cargando el index de bloques...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Agrega un nodo para conectarse and attempt to keep the connection open</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Cargando cartera...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>No es posible desactualizar la billetera</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>No se pudo escribir la dirección por defecto</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Rescaneando...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Carga completa</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
</context>
</TS>