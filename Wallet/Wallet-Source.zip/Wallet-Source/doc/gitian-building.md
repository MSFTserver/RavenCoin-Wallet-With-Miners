Gitian building
================

This file was moved to [the Raven Core documentation repository](https://github.com/raven-core/docs/blob/master/gitian-building.md) at [https://github.com/raven-core/docs](https://github.com/raven-core/docs).
