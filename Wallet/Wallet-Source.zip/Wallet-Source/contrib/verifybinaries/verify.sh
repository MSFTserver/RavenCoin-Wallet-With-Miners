#!/bin/bash
# NOOP
# Manual verify the published SHA256 hash against the SHA256 of the downloaded binary.
